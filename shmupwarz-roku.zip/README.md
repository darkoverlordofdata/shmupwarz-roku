# shmupwars-roku

starting with a deconstruction of [Prince of Persia for Roku](https://github.com/lvcabral/Prince-of-Persia-Roku), to find the bare minumum needed on roku.

