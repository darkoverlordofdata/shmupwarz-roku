# shmupwars-roku

starting with a deconstruction of ![Prince of Persia for Roku](http://lvcabral.com/images/PoP/screenshot-01.jpg)

